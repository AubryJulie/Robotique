if exist('loaded') == 0
    run('../../../../../matlab/startup_robot.m');
    loaded = true;
end
close all;
dashboard;