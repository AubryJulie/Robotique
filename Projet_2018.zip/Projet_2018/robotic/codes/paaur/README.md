TRS: An Open-source Recipe for Teaching/Learning Robotics with a Simulator 

See http://ulgrobotics.github.io/trs/ 

The `matlab` folder contains interesting functions to help write MATLAB scripts that use V-REP. 

The 'extra' folder in order to test the different scripts.

The 'youbot_withBaskets' folder implements the milestone C1 et A1

The 'youbot_withoutBaskets' folder implements the milestone A1

In the two youbot a simple command 'start' will open the user interface and start the youBot and download if not already done the Robert Corke Toolbox.
Matlab 2016b is needed.