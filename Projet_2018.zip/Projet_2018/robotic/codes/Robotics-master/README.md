TO DO


antoine : 
function findPointForExplore(map)
search for video capture and add sound to video file.

pierre:
move the robot to the given location.
stick to the path.

??
Create model for robot.
control loop.
